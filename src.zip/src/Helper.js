const shuffle = (arr) => { 
    for (let i = arr.length - 1; i > 0; i--) { 
      const j = Math.floor(Math.random() * (i + 1)); 
      [arr[i], arr[j]] = [arr[j], arr[i]]; 
    } 
    return arr; 
  }; 

let getParagraph = ()=>{

    let p = `Was enough That question kept asking himself being satisfied enough He looked around everyone yearning satisfied daily life and reached that goal knew that satisfied and also knew wasn't going enough`.split(" ");
    p = shuffle(p);
    return p;  

}

export {getParagraph}