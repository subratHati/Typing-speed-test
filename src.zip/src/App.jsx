// import './App.css'
import TypeSpeed from './TypeSpeed'
import Test from './Tester'
import Timer from './Timer'

function App() {
 
  return (
    <>
    <h2 style={{textAlign:"center"}}>Here is your type speed</h2>
      <TypeSpeed/>
    </>
  )
}

export default App
